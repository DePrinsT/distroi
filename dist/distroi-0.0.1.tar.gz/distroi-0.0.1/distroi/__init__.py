"""
This package allows for the calculation of optical interferometry (OI) observables from radiative transfer images.
"""