"""
Package containing auxiliary modules for reading in OIFITS data. Original modules written by A. Corporaal and J. Kluska.
"""